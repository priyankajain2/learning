package com.cg.ibs.investment.bean;

public class DirectClubbing { 

	
	    private Integer mfPlanId;
	    private String title;
	    private Double nav;
	    private Double mfAmount;
	    private Double units;
	    public Integer getMfPlanId() {
	        return mfPlanId;
	    }
	    public void setMfPlanId(Integer mfPlanId) {
	        this.mfPlanId = mfPlanId;
	    }
	    public String getTitle() {
	        return title;
	    }
	    public void setTitle(String title) {
	        this.title = title;
	    }
	    public Double getNav() {
	        return nav;
	    }
	    public void setNav(Double nav) {
	        this.nav = nav;
	    }
	    public Double getMfAmount() {
	        return mfAmount;
	    }
	    public void setMfAmount(Double mfAmount) {
	        this.mfAmount = mfAmount;
	    }
	    public Double getUnits() {
	        return units;
	    }
	    public void setUnits(Double units) {
	        this.units = units;
	    }
	    

	 

	}


