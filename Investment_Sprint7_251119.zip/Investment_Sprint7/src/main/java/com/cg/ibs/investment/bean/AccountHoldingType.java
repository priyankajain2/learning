package com.cg.ibs.investment.bean;

public enum AccountHoldingType {
	PRIMARY, SECONDARY, INDIVIDUAL
}
